<script setup>
import Home from './views/Home.vue';
</script>
<template>
  <div>
    <Home />
  </div>
</template>
