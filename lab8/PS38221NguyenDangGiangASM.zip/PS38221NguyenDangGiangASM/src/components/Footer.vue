<template>
  <footer class="p-2 text-light bg-dark text-center fixed-bottom">
    © Copyright by PFT Polytechnic
  </footer>
</template>
