<template>
  <div class="container justify-content-between align-content-center">
    <nav class="navbar navbar-expand-lg navbar-light p-2 shadow-sm bg-light">
      <div class="container-xxl">
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav me-auto">
            <li class="nav-item px-5 mx-4">
              <RouterLink to="/">Bài 2</RouterLink>
            </li>
            <li class="nav-item px-5 mx-4">
              <RouterLink to="/bai3">Bài 3</RouterLink>
            </li>
            <li class="nav-item px-5 mx-4">
              <RouterLink to="/bai4">Bài 4</RouterLink>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="container">
      <RouterView />
    </div>
  </div>
</template>

<style>
body {
  display: block;
}
</style>
