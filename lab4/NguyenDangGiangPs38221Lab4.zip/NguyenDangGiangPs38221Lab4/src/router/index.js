import { createRouter, createWebHistory } from "vue-router";
import Hello from "../components/bai2.vue";
import Bai3 from "../components/bai3.vue";
import Bai4 from "../components/bai4.vue";

const routes = [
  { path: "/", component: Hello },
  { path: "/bai3", component: Bai3 },
  { path: "/bai4", component: Bai4 },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router
