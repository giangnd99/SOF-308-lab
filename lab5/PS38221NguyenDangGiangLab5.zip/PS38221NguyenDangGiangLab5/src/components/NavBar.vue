<template>
  <ul class="nav justify-content-center">
    <li class="nav-item">
      <router-link class="nav-link" to="/">Bài 1</router-link>
    </li>
    <li class="nav-item">
      <router-link class="nav-link" to="/bai2"> Bài 2</router-link>
    </li>
    <li class="nav-item">
      <router-link class="nav-link" to="/bai3"> Bài 3</router-link>
    </li>

    <li class="nav-item">
      <router-link class="nav-link" to="/bai4"> Bài 4</router-link>
    </li>
  </ul>
</template>
